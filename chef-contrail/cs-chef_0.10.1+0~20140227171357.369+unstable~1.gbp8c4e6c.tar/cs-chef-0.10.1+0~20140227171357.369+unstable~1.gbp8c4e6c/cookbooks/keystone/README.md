Description
===========
WIP

Requirements
============
WIP

Definitions
===========
keystone_paclage
------------
This handles installing keystone package generically and managing it as service

Resources/Providers
===================

Recipes
=======
default
---
WIP

server
------
WIP

test_user
-------
WIP

