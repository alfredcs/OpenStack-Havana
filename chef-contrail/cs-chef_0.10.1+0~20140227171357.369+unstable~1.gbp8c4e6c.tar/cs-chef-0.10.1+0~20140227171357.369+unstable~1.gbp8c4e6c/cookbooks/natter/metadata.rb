name             "natter"
maintainer       "The Cloudscaling Group, Inc."
maintainer_email "pd@cloudscaling.com"
license          "All rights reserved"
description      "Installs/Configures natter"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
depends          "mysql"
