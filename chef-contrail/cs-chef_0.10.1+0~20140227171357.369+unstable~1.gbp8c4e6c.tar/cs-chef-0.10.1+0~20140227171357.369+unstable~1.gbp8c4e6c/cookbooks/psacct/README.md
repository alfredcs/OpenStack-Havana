DESCRIPTION
===========

Installs and configures psacct

LICENSE AND AUTHOR
==================

Author:: Eric windisch (<eric@cloudscaling.com>)

Cloudscaling Proprietary and Confidential

Copyright 2011 The Cloudscaling Group, Inc.  All rights reserved.
