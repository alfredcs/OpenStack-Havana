#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


import sys
import os

from nova import db
from nova import exception
from nova import flags
from nova import log as logging
from nova import utils
from sqlalchemy.orm import joinedload
from sqlalchemy.orm import joinedload_all
from nova.db.sqlalchemy.session import get_session
from nova.db.sqlalchemy import models
from nova import context
from nova import utils

import logger

import time

FLAGS = flags.FLAGS
utils.default_flagfile()
flags.FLAGS(sys.argv)

ctxt = context.get_admin_context()
session = get_session()

class DBMonitor:
    """ 
    This class allows Natter to communicate to Nova's database
    """
    def check(self):
        """
        Return a timestamp of when the database was last modified
        with regard to NAT rule changes
        """
        latest_time = None
        try:
            # Get floating IPs that arent None, order by last updated descending and return first record
            net = session.query(models.FloatingIp).filter(models.FloatingIp.updated_at != None).order_by(models.FloatingIp.updated_at.desc()).first()
            latest_time = net['updated_at']
        except Exception, e:
            logger.log.error('Fatal error communicating with nova database')
            logger.log.error('%r' % e)

        return latest_time

    def get_floating_map(self):
        """
        Query the Nova floating_ip table and derive a list of public to private IP mappings
        Returns a list of tuples: [(pub_ip1, priv_ip1), (pub_ip2, priv_ip2)]
        """
        result = []
        try:
            # Nova doesn't current offer rich enough data access APIs hence direct SQL
            # Return all records from floating_ips where deleted not 0, join with
            # fixed_ips on the fixed_ip_id field
            net = session.query('floating', 'fixed').from_statement("select floating_ips.address as floating,\
                                  fixed_ips.address as fixed from floating_ips join \
                                  fixed_ips where floating_ips.fixed_ip_id \
                                  = fixed_ips.id and floating_ips.deleted = 0").all()
            # Generate list
            for x in net:
                (floatip, fixedip) = x
                result.append(x)

        except Exception, e:
            logger.log.error('Fatal error communicating with nova database')
            logger.log.error('%r' % e)

        return result

    
