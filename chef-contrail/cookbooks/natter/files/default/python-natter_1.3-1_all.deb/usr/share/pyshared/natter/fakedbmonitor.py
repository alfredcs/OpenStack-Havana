#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import sys
import os
import time

class DBMonitor:
    """
        This class can be used to test natter without having a proper Nova database set up
    """
    def __init__(self):
        # Holds the rules that will be returned to natter when it asks for them
        self.fake_rules = []    

    def set_fake_rules(self, rules):
        """
        Function to set the fake rules from within a test
        This should be a list of tuples (public_ip, private_ip)
        """
        self.fake_rules = rules

    def check(self):
        """
        Normally this returns the time stampe of last record change
        In this fake class it just returns the current time so a reload is always triggered
        """
        return time.time()

    def get_floating_map(self):
        """
        Return a list of tuples back to Natter 
        Example: [(pub_ip1, priv_ip1), (pub_ip2, priv_ip2)]
        """
        return self.fake_rules

