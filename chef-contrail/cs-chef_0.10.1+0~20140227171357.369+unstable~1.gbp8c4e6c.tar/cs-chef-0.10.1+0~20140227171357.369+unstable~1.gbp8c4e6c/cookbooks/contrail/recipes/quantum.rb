#TODO(jpg) break out vnc_api python module so contrail-api
# doesn't need to be included here.
package 'contrail-api-lib'
package 'python-quantum'
package 'quantum-common'
package 'quantum-server'
package 'quantum-plugin-contrail'
