#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os

PROC_PATH = '/proc'

class LinuxUtil:
    """
    This class wraps some utilities for access the local linux system
    """
    def check_ip_forward(self, interface):
        """
            Check that IPv4 forwarding is enabled on specified interface
        """
        path = '%s/sys/net/ipv4/conf/%s/forwarding' % (PROC_PATH, interface)
        return self._isproctrue(path)

    def check_rp_filter(self, interface):
        """
            Check that IPv4 reverse path filtering is enabled on specified interface
            We typically want this disabled because of triggering martian filtering
        """
        path = '%s/sys/net/ipv4/conf/%s/rp_filter' % (PROC_PATH, interface)
        return self._isproctrue(path)
            
    def _isproctrue(self, path):
        """
            Evaluates the contents of a proc file
            If file contains 0, return False
            If file contains 1, return True
        """
        if self._getprocvalue(path) == '1':
            return True
        else:
            return False
            
    def _getprocvalue(self, path):
        """
            Returns the contents of a proc file path as a string
        """
        if os.path.exists(path):
            return file(path, 'r').read().strip()



