beaver_log "quantum" do
  file "/var/log/quantum/*"
  type "quantum"
end
