default['natter']['public_interface'] = "eth1"
default['natter']['public_block'] = "1.0.0.0/24"
default['natter']['private_block'] = "10.50.0.0/24"
