default.memcached.app_ip = OCS.app_ip(node)
default.memcached.port = 11211
default.memcached.log_file = "/var/log/memcached.log"
default.memcached.mem_cap = 64
default.memcached.user = "memcache"
default.memcached.connections = 1024
