DESCRIPTION
===========

Installs and configures ntp for OCS nodes.
