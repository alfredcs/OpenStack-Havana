#
# Cloudscaling Proprietary and Confidential
#
# Copyright 2011 The Cloudscaling Group, Inc.  All rights reserved.
#

name             "default"
maintainer       "Example Com"
maintainer_email "ops@example.com"
license          "Apache 2.0"
description      "Installs/Configures default"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.1"
