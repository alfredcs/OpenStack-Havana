name             "quantum"
maintainer       "Cloudscaling, Inc."
maintainer_email "abhishek@cloudscaling.com"
license          "Apache 2.0"
description      "The OpenStack Networking service Quantum."
version          "0.1.1"

depends          "contrail"
depends          "mysql"
depends          "keystone"

supports         "ubuntu"
