
#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


import netaddr
import os
import re
from subprocess import Popen, PIPE, STDOUT


DEFAULT_INTERFACE = 'eth0'
DEFAULT_EGRESS_HANDLE_START = 100
DEFAULT_INGRESS_HANDLE_START = 200

TC_COMMAND = '/sbin/tc'

class TCManager:
    def __init__(self):
        self.public_blocks = []
        self.private_blocks = []
        self.nat_rules = []
        self.interface = DEFAULT_INTERFACE
        self.handle_map = {}

    def verify_tc(self):
        """
            Check tc 
        """
        if os.system('%s qdisc show' % TC_COMMAND) == 0:
            return True
        else:
            return False
            
    def add_private_block(self, cidr):
        """
            Add a new block of IPv4 addresses to NAT on egress
        """
        self.private_blocks.append(cidr)

    def add_public_block(self, cidr):
        """
            Add a new block of IPv4 addresses to NAT on ingress
        """
        self.public_blocks.append(cidr)

    def set_interface(self, interface):
        """
            Specify the interface we are doing NAT on, usually ingress interface
        """
        self.interface = interface

    def add_nat_rule(self, public_ip, private_ip):
        """ 
            Add new rule that specifies a mapping between a given public address to private
        """
        self.nat_rules.append( (public_ip, private_ip) )


    def _compile_tc_init_config(self):
        """
            Create tc commands to clear our previous config and setup new qdiscs
            The output of this function goes in the beginning of the tc batch config
        """
        tcconfig = "qdisc add dev %s root handle 1: prio\n" % self.interface 
        tcconfig += "qdisc add dev %s ingress\n" % self.interface
        return tcconfig

    def _compile_tc_hashbuckets(self):
        """
            For each private and public block of IPv4 addresses we create a hash in TC
            This is used to minimize the number of rules traversed per packet
            This part of the tc batch config goes before the rule defition
            The handles for each hash are defined in this function and used later
                in rule generation
        """
        egress_index = DEFAULT_EGRESS_HANDLE_START
        ingress_index = DEFAULT_INGRESS_HANDLE_START

        self.handle_map = {}

        egress_template = \
            "filter add dev %s parent 1: prio 5 handle %s: protocol ip u32 divisor 256\n" \
            "filter add dev %s protocol ip parent 1: prio 5 u32 ht 800:: match ip src %s hashkey mask 0x000000ff at 12 link %s:\n"


        ingress_template = \
            "filter add dev %s parent ffff: prio 5 handle %s: protocol ip u32 divisor 256\n" \
            "filter add dev %s protocol ip parent ffff: prio 5 u32 ht 800:: match ip dst %s hashkey mask 0x000000ff at 16 link %s:\n"

        tcconfig = ""

        # setup egress hash-buckets to catch private addresses
        for block in self.private_blocks:
            tcconfig += egress_template % (
               self.interface, 
               str(egress_index),
               self.interface,
               block,
               str(egress_index) 
               )               
            self.handle_map[block] = egress_index
            egress_index += 1

        # setup ingress hash-buckets to catch public addresses
        for block in self.public_blocks:
            tcconfig += ingress_template % (
                self.interface,
                str(ingress_index),
                self.interface,
                block,
                str(ingress_index)
                )
            self.handle_map[block] = ingress_index
            ingress_index += 1

        return tcconfig

    def _bucketize(self, ip):
        """
            Deterministically convert an IP address into a tc hash key
            Hex representation of last IPv4 octet
        """
        return "%02x" % int(ip.split('.')[-1])

    def matching_cidrs(self, ip, block):
        """
            Using python netaddr see if a given IP calls in any CIDRs in list
        """
        return [str(x) for x in netaddr.all_matching_cidrs(ip, block)]

    def find_block(self, ip, blocks):
        """
            Iterate through the list of CIDRs that an IP address belongs to
            return string representation of of the first matching CIDR
            return None if there is no match 
        """
        cidrs = self.matching_cidrs(ip, blocks)
        if len(cidrs) > 0:
            return(cidrs[0])
        
    def _compile_tc_nat_rules(self):
        """
            Construct a list of tc rules that link to the various hash key entries
            A NAT rule is specified for each direction of the flow
            egress_filter will convert outgoing private address into public
            ingress
        """
        print "COMPILE"
        tcconfig = ""
        for (public_ip, private_ip) in self.nat_rules:
            private_cidr = self.find_block(private_ip, self.private_blocks)
            public_cidr = self.find_block(public_ip, self.public_blocks)

            egress_filter_template = \
                "filter add dev %s parent 1: protocol ip prio 5 u32 ht %s:%s match ip src %s/32 action nat egress %s/32 %s/32\n"

            ingress_filter_template = \
                "filter add dev %s parent ffff: protocol ip prio 5 u32 ht %s:%s match ip dst %s/32 action nat ingress %s/32 %s/32\n"

            # only add rule if blocks for each are found
            if private_cidr and public_cidr:

                # apply egress filter
                tcconfig += egress_filter_template % (
                    self.interface,
                    self.handle_map[private_cidr],
                    self._bucketize(private_ip),
                    private_ip,
                    private_ip,
                    public_ip
                    )

                # apply ingress filter
                tcconfig += ingress_filter_template % (
                    self.interface,
                    self.handle_map[public_cidr],
                    self._bucketize(public_ip),
                    public_ip,
                    public_ip,
                    private_ip
                    )

        return tcconfig   


    def compile_tc_config(self):
        """
            Emit a bunch of tc commands derived from the IP blocks and rules previously specified
            Output is a string that can be fed into tc -batch
        """
        tcconfig = self._compile_tc_init_config()

        tcconfig += self._compile_tc_hashbuckets()

        tcconfig += self._compile_tc_nat_rules()

        return tcconfig
    
    def commit_tc_config(self, tcconfig):
        """
            Load config into tc (kernel)
        """
        # take out the batch mode for debugging
        #p = Popen(['tc', '-batch'], stdout=PIPE, stdin=PIPE, stderr=STDOUT)
        #output =  p.communicate(input=tcconfig)[0]
        print "COMMIT"
        for line in tcconfig.split('\n'):
            if line:
                cmd = "%s %s" % (TC_COMMAND, line)
                print "Running command: %s" % cmd
                os.system(cmd)
            

    def check_dev_qdisc(self, device, handle):
        """
            Check if specified qdisc exists
        """
        tcout = os.popen('%s qdisc show' % TC_COMMAND).read()
        search_str = " %s dev %s " % (handle, device)
        if tcout and search_str in tcout:
            return True
        else:
            return False
    
    def clear_tc_handles(self):
        """
            Delete the ingress and egress qdiscs
            This is done because we currently reload rules instead of insert/delete
        """
        tcconfig = ""

        if self.check_dev_qdisc(self.interface, '1:'):
            tcconfig += "qdisc del dev %s root handle 1:\n" % self.interface

        if self.check_dev_qdisc(self.interface, 'ingress ffff:'):
            tcconfig += "qdisc del dev %s ingress\n" % self.interface

        if tcconfig != '':
            self.commit_tc_config(tcconfig)

    def read_live_rules(self, device, path):
        """
            Very primitive attempt to read tc filter output and infer existing rules on system
        """
        results = []
        cmd = "%s filter show dev %s %s" % (TC_COMMAND, device, path)
        print "cmd: %s " % cmd
        tc_output = os.popen(cmd).read()
        entries = [x.replace('\n', '') for x in tc_output.split('filter ')]
        for x in entries:
            # fh 100:5f:800
            pattern = 'fh ([0-9a-f]+:[0-9a-f]+:[0-9a-f]+)'
            m = re.search(pattern, x)
            fh = None
            if m:
                fh = m.groups()[0]

            pattern = 'nat (i?e?n?gress)\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/\d{1,3}\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
            m = re.search(pattern, x)
            if m:
                rule_tuple = m.groups()
                results.append(rule_tuple+(fh,))
        return results
                             


