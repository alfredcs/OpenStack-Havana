Description
===========

Does setup specific to ubuntu such as APT repositories, etc.

Recipes
=======

default
-------

Resources/Providers
===================

Usage
=====

Put `recipe[ubuntu]` in the run list.

License and Author
==================

Author:: Blake Barnett (<bdb@cloudscaling.com>)

Copyright 2013 Cloudscaling, Inc.
