name             "git"
maintainer       "Cloudscaling Group, Inc"
maintainer_email "eric@cloudscaling.com"
license          "All rights reserved"
description      "Installs/Configures git"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
