Description
===========
Cookbook for shared OpenStack configuration.

Requirements
============
None

Definitions
===========
None

Resources/Providers
===================
None

Recipes
=======

