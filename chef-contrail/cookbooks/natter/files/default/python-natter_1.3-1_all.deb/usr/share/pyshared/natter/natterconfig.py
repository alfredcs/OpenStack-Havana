#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


import ConfigParser
import logger
import os

DEFAULT_CONFIG_PATH = "/etc/natter/natter.conf"

class NATManagerConfig:
    """
        Generic facility to pull in Natter configuration
    """
    def __init__(self, config_path=DEFAULT_CONFIG_PATH):
        """
        Use default confg file path or use the one specified in constructor
        """
        self.config_path = config_path

    def load(self):
        """
        Read contents of config file and return hash with interface, and ip blocks
        """
        logger.log.error('Loading config file: %s' % self.config_path)
        cfg = {}
        if os.path.exists(self.config_path): 
            cp = ConfigParser.ConfigParser()
            cp.read(self.config_path)
            cfg['interface'] = cp.get("CONFIG", "interface")
            cfg['public_block'] = cp.get("CONFIG", "public_block")
            cfg['private_block'] = cp.get("CONFIG", "private_block")
            logger.log.error('Interface: %s' % cfg['interface'])
            logger.log.error('Public Block: %s' % cfg['public_block'])
            logger.log.error('Private Block: %s' % cfg['private_block'])
        else:
            logger.log.error('Config file specified does not exist')
        return cfg
            
if __name__ == '__main__':
    nc = NATManagerConfig()
    cfg = nc.load()
    


