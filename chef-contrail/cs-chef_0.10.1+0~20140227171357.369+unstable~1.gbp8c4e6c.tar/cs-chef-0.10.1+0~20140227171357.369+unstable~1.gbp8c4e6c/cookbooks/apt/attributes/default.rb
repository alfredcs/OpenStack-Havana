default['apt']['repository']['docroot'] = "/srv/pkg"
default['apt']['repository']['server_name'] = ""
default['apt']['cacher_ng']['url'] = 'localhost:3142'
