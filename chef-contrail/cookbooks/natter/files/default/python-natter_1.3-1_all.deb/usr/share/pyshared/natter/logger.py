#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import logging

APP_NAME = 'natter' 
LOG_DIR = '/var/log'

class Logger:
    """ 
    Generic facility to log Natter related stuff 
    """
    def __init__(self):
        lg = logging.getLogger(APP_NAME)
        hdlr = logging.FileHandler('%s/%s.log' % (LOG_DIR, APP_NAME))
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        hdlr.setFormatter(formatter)

        lg.addHandler(hdlr)
        lg.setLevel(logging.DEBUG)

        self._lg = lg

    def error(self, msg):
        """ 
        Log an error
        """
        self._lg.error(msg)

    def info(self, msg):
        """
        Log debug info
        """
        self._lg.info(msg) 

log = Logger()

if __name__ == '__main__':
    l = Logger()
    l.error('This is an error level error')
    l.info('This is an info level error')

