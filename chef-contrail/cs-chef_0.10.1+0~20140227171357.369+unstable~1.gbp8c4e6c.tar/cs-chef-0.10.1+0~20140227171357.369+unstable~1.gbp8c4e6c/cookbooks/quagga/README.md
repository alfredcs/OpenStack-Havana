Quagga cookbook
===============

Sets up quagga ospfd and zebra daemons
