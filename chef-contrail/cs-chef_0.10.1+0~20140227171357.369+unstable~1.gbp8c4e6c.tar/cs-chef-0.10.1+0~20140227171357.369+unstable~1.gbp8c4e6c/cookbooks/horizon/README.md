Description
===========
Cookbook and recipes for deploying OpenStack Horizon.

Requirements
============
OCS v2.0+
Ubuntu Precise

Definitions
===========

Resources/Providers
===================

Recipes
=======

default
-------
Installs horizon and configures Apache.
