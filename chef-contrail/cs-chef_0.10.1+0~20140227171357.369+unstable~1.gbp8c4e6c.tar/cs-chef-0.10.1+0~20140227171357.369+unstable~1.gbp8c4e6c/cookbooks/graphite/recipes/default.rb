package "python-whisper"

include_recipe "graphite::dashboard"
include_recipe "graphite::carbon"
