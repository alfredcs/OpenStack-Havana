# Author:: Benjamin Staffin <ben@cloudscaling.com>
# Cookbook Name:: zabbix
# Recipe:: default

include_recipe "zabbix::install_agent"
