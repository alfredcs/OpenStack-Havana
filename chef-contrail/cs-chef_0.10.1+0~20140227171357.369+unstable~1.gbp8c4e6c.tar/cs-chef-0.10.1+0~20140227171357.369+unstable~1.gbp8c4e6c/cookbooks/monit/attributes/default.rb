# Sane monit defaults
default['monit']['log_file'] = "/var/log/monit.log"
default['monit']['polling_interval'] = 1
default['monit']['httpd_port'] = 2812
default['monit']['username'] = "monit"
default['monit']['password'] = "monit"
