#    Copyright 2012 Cloudscaling Group, Inc
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


import linux
import natterconfig
import os
import sys
import time
from tc import TCManager

import logger 

INTERVAL = 5

# some unit tests may set this to True to stub out Nova
FAKE = False 

class NatterMain:
    """
    Main class for Natter's logic
    """
    def __init__(self):
        if FAKE:
            logger.log.error('Using FAKE mock database db monitor')
            from fakedbmonitor import DBMonitor as dbm
        else:
            logger.log.error('Using Nova database db monitor')
            try:
                from novadbmonitor import DBMonitor as dbm
            except Exception:
                logger.log.error('Fatal error: Nova modules not installed properly on this machine')
                sys.exit()
        self.db = dbm()
        self.RUN = True
        self.last_tcconf = None
        self.natter_config = natterconfig.NATManagerConfig().load()
        self.tc_commit = True

        

    def check_linux(self):
        """ 
            Warn about a few prerequisite system level settings
        """
        interface = self.natter_config['interface']

        l = linux.LinuxUtil()
        forwarding_enabled = l.check_ip_forward(interface)
        rp_filtering_enabled = l.check_rp_filter(interface)

        if not forwarding_enabled:
            logger.log.error("WARNING: IP Forwarding is not enabled")

        if rp_filtering_enabled:
            logger.log.error("WARNING: rp_filtering/martian filtering is enabled")

    def start(self):
        """
        Entry-point for service when it starts up
        """
        logger.log.error("Starting Natter Engine")
        
        # check some needed system settings are set correctly
        self.check_linux()

        last_time = None
        while self.RUN:

            # Check Nova for any new record updates
            current_time = self.db.check()

            #If there is an update reload the NAT rules
            if current_time != last_time:
                logger.log.error("New rules detected, updating. Time stamp %s != %s " % (current_time, last_time) )
                self.update_rules()
                last_time = current_time
            
            #wait for some time
            time.sleep(INTERVAL)

    def stop(self):
        """
        This should stop the main loop of the service
        """
        logger.log.error("Stopping Natter")
        self.RUN = False
        
    def update_rules(self):
        """
        This function will get a mapping of IPs from nova and
        commit them into the tc filter list
        """

        # a list of tuples should be returned [(pub,priv),]
        ipmap = self.db.get_floating_map()
 
        logger.log.error("%d rules to inject" % len(ipmap) )
        tcm = TCManager()
        if not tcm.verify_tc():
            logger.log.error("Linux tc(iproute2) doesn't seem to be on system")
            return

        tcm.set_interface(self.natter_config['interface'])

        # remove existing TC qdiscs because we repopulate the entire list
        # TODO: This logic will be replaced with optimized in place rule modification
        tcm.clear_tc_handles()

        # The blocks need to be specified to determine tc hash buckets
        tcm.add_private_block(self.natter_config['private_block'])
        tcm.add_public_block(self.natter_config['public_block'])
      
        # Apply all the entries from the nova nat/floating ip db into ruleset
        for pub,priv in ipmap:
            tcm.add_nat_rule(pub, priv)

        # Compile the commands that should be sent to TC into one string
        tconf = tcm.compile_tc_config()

        # Save this so that tests can analyze 
        self.last_tcconf = tconf

        # The default behavior is to send the TC commands to be run by system
        if self.tc_commit:
            logger.log.error("Committing new config to linux kernel TC")
            tcm.commit_tc_config(tconf)

if __name__ == '__main__':
    nm = NatterMain()
    nm.start()
   



