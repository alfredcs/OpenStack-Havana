actions :rain

default_action :rain

attribute :cloud_name, :kind_of => String
